//
//  AccountsViewController.h
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 08/04/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "CoreDataAccTableViewController.h"

@interface AccountsViewController : CoreDataAccTableViewController <NSFetchedResultsControllerDelegate>

@end
