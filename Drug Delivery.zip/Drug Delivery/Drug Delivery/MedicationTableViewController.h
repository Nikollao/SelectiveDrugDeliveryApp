//
//  MedicationTableViewController.h
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 23/01/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "CoreDataTableViewController.h"

@interface MedicationTableViewController : CoreDataTableViewController

@property (nonatomic) BOOL addPressed;

@end
