//
//  MedicationThreePickerTextField.h
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 24/02/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "CoreDataPickerTextField.h"

@interface MedicationThreePickerTextField : CoreDataPickerTextField

-(void)fetch;

@end
