//
//  AccountHolder.m
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 08/04/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "AccountHolder.h"

@implementation AccountHolder

@dynamic userName;
@dynamic fullName;
@dynamic password;
@dynamic repeatPassword;
@dynamic occupation;
@dynamic fullNameFirstChar;

@end
