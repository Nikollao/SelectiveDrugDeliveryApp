//
//  BLEDeviceTableViewCell.m
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 10/02/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "BLEDeviceTableViewCell.h"

@implementation BLEDeviceTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
