//
//  MedicationPickerTextField.h
//  Drug Delivery
//
//  Created by Nikollao Sulollari on 23/01/2017.
//  Copyright © 2017 University of Leeds. All rights reserved.
//

#import "CoreDataPickerTextField.h"

@interface MedicationPickerTextField : CoreDataPickerTextField

-(void)fetch;

@end
